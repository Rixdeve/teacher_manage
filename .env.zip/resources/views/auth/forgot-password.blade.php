<!-- <form method="POST" action="{{ route('password.email') }}">
    @csrf
    <input type="email" name="user_email" placeholder="Enter your email" required />
    <button type="submit">Send Password Reset Link</button>
</form>
@if(session('status'))
<p>{{ session('status') }}</p>
@endif -->